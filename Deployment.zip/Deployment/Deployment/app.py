from flask import Flask, request,render_template
import singleUpload
import customUpload
import pandas as pd

app = Flask(__name__)
app.static_folder = 'static'
app.config['UPLOAD_FOLDER'] = './static'


@app.route('/')
def home():
    return render_template('index.html')


@app.route('/single-review', methods=['GET', 'POST'])
def single_review():
    if request.method == "POST":
        review = request.form['review']
        review = singleUpload.run(review)
        return render_template('single-review.html', review=review)

    return render_template('single-review.html')

@app.route('/custom-review', methods=['GET', 'POST'])
def custom_review():
    if request.method == "POST":
        # get the csv file
        file1 = request.files['csvFile']
        file_name = file1.filename
        file1.save('./static/files/'+file_name)
        df = pd.read_csv('./static/files/'+file_name)
        img_path = customUpload.run(df, file_name)

        return render_template("custom-review.html", img_path=img_path)
        # file1.save('./static/'+file1.filename)
    return render_template("custom-review.html")



if __name__ == '__main__':
    app.run(debug=True)
