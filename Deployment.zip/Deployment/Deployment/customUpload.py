import joblib
import pandas as pd
import string
import numpy as np
from nltk.tokenize import word_tokenize
import matplotlib.pyplot as plt
import nltk
from nltk.stem import WordNetLemmatizer
from nltk.corpus import stopwords
nltk.download('stopwords')
nltk.download('punkt')
nltk.download('wordnet')
nltk.download('vader_lexicon')

def preprocess(text):
    # Convert to lowercase
    text = text.lower()
    # Remove punctuation
    text = text.translate(str.maketrans('', '', string.punctuation))   
    # Tokenize the text
    tokens = word_tokenize(text)  
    # Remove stopwords
    stopwords_list = stopwords.words('english')
    tokens = [token for token in tokens if token not in stopwords_list]
    #Lemmatize the tokens
    lemmatizer = WordNetLemmatizer()
    tokens = [lemmatizer.lemmatize(token) for token in tokens]  
    # Join the tokens back into text
    text = ' '.join(tokens)  
    return text

def run(csvFile, file_name):
    best_model = joblib.load('./static/models/best_model.pkl')

    test_df = csvFile
    test_df["review/text"] = test_df["review/text"].apply(preprocess)
    x_trial = test_df["review/text"]
    predictions = best_model.predict(x_trial)
    # Make predictions on the transformed test data using the saved model
    # print(predictions)
    unique_vals2, val_counts2 = np.unique(predictions, return_counts=True)
     
    # create chart

    labels = ['Negative', 'Neutral', 'Positive']
    sizes = val_counts2 / np.sum(val_counts2)
    colors = ['red', 'orange', 'green']

    fig1, ax1 = plt.subplots()
    ax1.pie(sizes, labels=labels, colors=colors, autopct='%1.1f%%', startangle=90)
    ax1.axis('equal')

    plt.title('Brand Image')
    plt.text(-1.05, -1.2, file_name, fontsize=12)
    ax1.text(0, -1.1, f'Total Reviews: {np.sum(val_counts2)}', ha='center')
    fig1.set_facecolor('#d3eef5')  # set light blue background
    plt.savefig("./static/img/Output.png")
    return "./static/img/Output.png"
    # sentiment_map = {0: "Negative", 1: "Neutral", 2: "Positive"}
    # predicted_sentiment = sentiment_map[predictions[0]]
    # return  predicted_sentiment

# run("dss")